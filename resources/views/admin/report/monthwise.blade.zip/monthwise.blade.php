@extends('admin.layouts.master')
@push('link')
<link rel="stylesheet" href="{{ asset('assets/jquery-toast-plugin/jquery.toast.min.css') }}" />
@endpush
@section('content')
<div class="page-title-box">
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div>
                    <h4 class="header-title">{{ __('Monthly Reports') }}</h4><br>
                </div>
                <div class="row mt-4 ml-4 mb-4 no-print">
                    <form class="form-inline" id="filter-form">
                        <label for="start_date">From Date: </label>
                        <input type="text" class="form-control datepicker ml-3" autocomplete="off" id="from_date" name="start_date" required>          
                        <label for="start_date" class="ml-4">To Date: </label>
                        <input type="text" class="form-control datepicker ml-3" autocomplete="off" id="to_date" name="end_date" required>          
                        
                        <button type="submit" class="btn btn-info ml-3">Filter</button>
                    </form>
                    <button id="printBtn" class="btn btn-success ml-4">Print Report</button>
                </div>
                <div id="printSection">
                    <div class="text-center mt-4">
                        <h4 style="text-align:center;">Dhoya Restaurant</h4>
                        <h5 style="text-align:center;">RC Street, Court Para</h5>
                        <h5 style="text-align:center;">Kushtia(+8801873690534)</h5>
                        <h5 style="text-align:center;" id="filterDate"></h5>
                    </div>
                    <table id="report-table" class="table table-border table-striped">
                        <thead>
                            <tr>
                                <!-- <th>SL</th> -->
                                <th>Order No</th>
                                <th>Category</th>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div>Total: <span id="total"></span></div>
                    <div class="endPrint"  style="font-size:12px;text-align:center">
                        <p>Powered by DIGITAL INNOVATION</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('style')
<style>
        .header-title{
            color: #213166;
        }
        .btn-primary{
            border-radius: 6px;
        }
        .btn-default:hover{
            color: black;
        }
        .action{
            padding-left: 22px!important;
        }
        .text-center{
            text-align: center;
            display: inherit!important;
        }
        @page {
            width: 3in;
            /* size: 80mm 297mm;  */
            margin: 20px;
            font-size: 10pt;
            font-family: Tahoma, Verdana, Segoe, sans-serif;
        }
        .printDiv{
            width: 3in;
            /* size: 80mm 297mm; 
            margin: 20px; */
            font-size: 10pt;
            font-family: Tahoma, Verdana, Segoe, sans-serif;
        }
        .datepicker{
            border: 1px solid cadetblue;
        }
        #wrapper .select2-container--default .select2-selection--single .select2-selection__rendered{
            width: 100px;
        }

        @media print {
            .no-print { display: none; }
        }
    </style>
@endpush

@push('script')
<script>
        $(document).ready(function() {
            // Initialize DataTable
            // var table = $('#report-table').DataTable();

            // Handle form submission to filter data
            $('#filter-form').on('submit', function(event) {
                event.preventDefault();

                let startDate = $('#from_date').val();
                let endDate = $('#to_date').val();

                // Fetch data via AJAX
                $.ajax({
                    url: "{{ route('admin.reports.month.data') }}",
                    method: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        start_date: startDate,
                        end_date: endDate
                    },
                    success: function(data) {
                        let tableBody = $('#report-table tbody');
                        tableBody.empty(); // Clear the existing data
                        // Clear existing table data
                        // table.clear().draw();
                        // Append new data to the table
                        data.forEach(report => {
                            
                            report.order_sku.forEach(value => {
                                tableBody.append(`
                                <tr>
                                    <td>${value.order_no}</td>
                                    <td>${value.category_name.name}</td>
                                    <td>${value.item_name}</td>
                                    <td>${value.quantity}</td>
                                    <td>${value.subtotal}</td>
                                </tr>
                            `);

                            });
                            let totals = report.total;
                            $('#total').text('৳ ' + totals);
                            var dateParts = startDate.split('-');
                            var year = dateParts[0];
                            var month = dateParts[1];
                            var day = dateParts[2];
                            var formattedDate = day + '-' + month + '-' + year;
                            $('#filterDate').text(formattedDate);
                        });
                    }
                });
            });

            // Print button functionality
            $('#printBtn').on('click', function() {
                window.print();
            });
        });
    </script>


@endpush